import Link from "next/link";
import React from "react";

const Main: React.FC<{}> = () => {
  return (
    <div>
      Here is main
      <Link href="/r/notShadeesCommunity">hehe</Link>
    </div>
  );
};
export default Main;
